# AlterU U Logo + U Agent Core Assets V1.6

发布日期：2026-08-19

## 目录

- `assets/logo/svg/`：收紧间距后的 U + ALTERU 横向组合，以及独立 U 标识
- `assets/logo/png/`：Logo 透明 PNG（512 / 1024 宽）
- `assets/mascot/svg/`：U Agent 表情、动作、气泡状态矢量文件
- `assets/mascot/png/`：吉祥物透明 PNG（512 / 1024 宽）
- `assets/motion/`：MiniAPP 动态 SVG、原生 App Lottie JSON 与接入说明
- `assets/examples/character/`：Character Edition 多视角与动作概念图
- `assets/examples/posters/`：三类实用传播场景的无字主视觉
- `assets/vi/`：色彩板、JSON Token、CSS Token
- `docs/asset-index.csv`：全部资产索引

## 快速使用

1. 深色产品背景使用 `alteru-logo-lockup-reversed.svg`。
2. 浅色宣传背景使用 `alteru-logo-lockup-primary-light.svg`。
3. 需要无损缩放、前端或印刷排版时使用 SVG；社交平台与办公软件使用 PNG。
4. 不修改官方 U 路径，不拆分脸与 U 的位置关系，不出现单只手。
5. 当前正式产品状态只有 `Create a game?` 与 `Your turn - I'm waiting` 两类。
6. 复杂手写字标不属于本版 VI，不进入正式资产目录。

## 版本说明

V1.6 不再包含 PDF 视觉识别手册，改由 HTML 核心交付页承担展示与说明。U 标志与 ALTERU 字标约 9.5px 的视觉净距保持不变，字标在 V1.5 基础上再下移 0.5px，最终累计下移 2px。标志路径、文字字形与内部字距保持不变。
