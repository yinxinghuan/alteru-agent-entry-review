# AlterU 小优家族与世界素材 v1.0

本包包含 10 张高分辨率 PNG，用于品牌传播、活动页面、社区内容与产品状态示意。

## family

- `family-portrait-expanded.png`：大家族合影
- `family-care-circle.png`：照顾与靠近
- `family-reaction-chorus.png`：反应合唱
- `family-generations-panorama.png`：成长与代际

## world

- `world-growth-paths.png`：生长路径
- `world-night-constellation.png`：星光迁徙
- `world-building-workshop.png`：搭建工坊
- `world-waiting-doorway.png`：等待入口
- `world-message-relay.png`：消息接力
- `world-game-bloom.png`：游戏萌芽

这些图片用于展示平面形象系统的扩展能力。需要加入文案与 Logo 时，请在排版软件或页面中独立叠加，避免直接修改角色轮廓与脸部颜色。
