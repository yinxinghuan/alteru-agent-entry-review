# AlterU U Logo + U Agent Core Assets v1.8

本包用于品牌 Logo、平台入口 U Agent、材质方向评审和海报场景制作。

## 正式可用

- `assets/logo/`：U 标识与 ALTERU 横向组合，SVG 与透明 PNG 1×/2×。
- `assets/mascot/`：无脚 U Agent 的静态 SVG 与透明 PNG 1×/2×。
- `assets/motion/`：MiniAPP/Web 动态 SVG、原生 Lottie JSON 与接入说明。
- `assets/vi/`：颜色与设计 Token。

## 仅用于评审

- `assets/material-explorations/`：蜡笔、毛绒、平面肌理、软胶四种质感探索。这些图片不是最终形象标准。
- `assets/poster-scenes/`：Create Game、Your Turn、Meet U 三张无文字高分辨率场景底图；可以在排版软件中独立叠加 Logo 与文案。

## 角色形状合同

- U 标识就是身体。
- 脸盘下方保留一个与 U 下弯连成整体的小圆肚。
- 角色没有脚；手臂只有 0 或 2 两种数量。
- 材质与表情可以变化，但 U 轮廓、粉色脸盘、白圈和双手结构不能丢失。

本版继续排除上一阶段带脚的 3D 角色图，并加入三张遵守“无脚 + 小肚子”合同的新海报场景。
